import matplotlib.pyplot as plt
import scipy.stats as stats
import historical_weather_functions as hwf

# File paths
ANN_ARBOR = 'ANN ARBOR U OF MICH, MI US.csv'
BLUE_HILL = 'BLUE HILL COOP, MA US.csv'
HOUSTON = 'HOUSTON WILLIAM P HOBBY AIRPORT, TX US.csv'
LA = 'LOS ANGELES DOWNTOWN USC, CA US.csv'
ALASKA = 'UNIVERSITY EXPERIMENTAL STATION, AK US.csv'

# Load all datasets
df_aa = hwf.load_and_process_dataframe(ANN_ARBOR)
df_bh = hwf.load_and_process_dataframe(BLUE_HILL)
df_hou = hwf.load_and_process_dataframe(HOUSTON)
df_la = hwf.load_and_process_dataframe(LA)
df_ak = hwf.load_and_process_dataframe(ALASKA)

for df in [df_aa, df_bh, df_hou, df_la, df_ak]:
    hwf.label_days_and_year(df)
    hwf.label_seasons(df)

# -------------------------------------------------------
# Q2: Single-day and annual average plots for TMIN + PRCP
# -------------------------------------------------------

# Q2a: TMIN on December 13 over all years
filtered_tmin = hwf.filter_by_month_and_day(df_aa, month=12, day=13)
filtered_tmin = filtered_tmin.dropna(subset=["TMIN"])

slope, intercept, r, p, se = stats.linregress(
    filtered_tmin["YEAR"], filtered_tmin["TMIN"]
)
fit_line = slope * filtered_tmin["YEAR"] + intercept
p_label = "fit: p=" + format(p, ".1e")

fig, ax = plt.subplots()
ax.scatter(
    filtered_tmin["YEAR"], filtered_tmin["TMIN"],
    label="TMIN on Dec 13", color="steelblue"
)
ax.plot(filtered_tmin["YEAR"], fit_line, color="red", label=p_label)
ax.set_xlabel("Year")
ax.set_ylabel("Min Temperature (tenths of C)")
ax.set_title("Min Daily Temp on December 13 Over Time (Ann Arbor)")
ax.legend()
plt.tight_layout()
plt.savefig("q2_tmin_oneday.png")
plt.close()

# Q2b: Annual average TMIN
annual_tmin = hwf.make_average_dataframe(df_aa, column="YEAR")
annual_tmin = annual_tmin[1:-1]

slope2, intercept2, r2, p2, se2 = stats.linregress(
    annual_tmin["YEAR"], annual_tmin["TMIN"]
)
fit_line2 = slope2 * annual_tmin["YEAR"] + intercept2
p2_label = "fit: p=" + format(p2, ".1e")

fig, ax = plt.subplots()
ax.scatter(
    annual_tmin["YEAR"], annual_tmin["TMIN"],
    label="Annual Avg TMIN", color="steelblue"
)
ax.plot(annual_tmin["YEAR"], fit_line2, color="red", label=p2_label)
ax.set_xlabel("Year")
ax.set_ylabel("Avg Min Temperature (tenths of C)")
ax.set_title("Annual Average Min Daily Temp Over Time (Ann Arbor)")
ax.legend()
plt.tight_layout()
plt.savefig("q2_tmin_annual_average.png")
plt.close()

# Q2c: Annual average PRCP (no single-day plot since rain on one day is noisy)
annual_prcp = hwf.make_average_dataframe(df_aa, column="YEAR")
annual_prcp = annual_prcp[1:-1].dropna(subset=["PRCP"])

slope3, intercept3, r3, p3, se3 = stats.linregress(
    annual_prcp["YEAR"], annual_prcp["PRCP"]
)
fit_line3 = slope3 * annual_prcp["YEAR"] + intercept3
p3_label = "fit: p=" + format(p3, ".1e")

fig, ax = plt.subplots()
ax.scatter(
    annual_prcp["YEAR"], annual_prcp["PRCP"],
    label="Annual Avg PRCP", color="steelblue"
)
ax.plot(annual_prcp["YEAR"], fit_line3, color="red", label=p3_label)
ax.set_xlabel("Year")
ax.set_ylabel("Avg Precipitation")
ax.set_title("Annual Average Precipitation Over Time (Ann Arbor)")
ax.legend()
plt.tight_layout()
plt.savefig("q2_prcp_annual_average.png")
plt.close()

# -------------------------------------------------------
# Q3: Annual average TMAX for 4 cities
# -------------------------------------------------------

cities = [
    (df_aa, "Ann Arbor, MI"),
    (df_bh, "Blue Hill, MA"),
    (df_hou, "Houston, TX"),
    (df_la, "Los Angeles, CA"),
]
colors = ["steelblue", "green", "orange", "red"]

fig, ax = plt.subplots()
for (df, label), color in zip(cities, colors):
    avg = hwf.make_average_dataframe(df, column="YEAR")
    avg = avg[1:-1].dropna(subset=["TMAX"])
    slope_c, intercept_c, r_c, p_c, se_c = stats.linregress(
        avg["YEAR"], avg["TMAX"]
    )
    fit = slope_c * avg["YEAR"] + intercept_c
    slope_label = (
        label + " (slope=" + format(slope_c, ".3f") + " F/yr)"
    )
    ax.scatter(avg["YEAR"], avg["TMAX"], color=color, s=5, alpha=0.5)
    ax.plot(avg["YEAR"], fit, color=color, label=slope_label)

ax.set_xlabel("Year")
ax.set_ylabel("Avg Max Temperature")
ax.set_title("Annual Average Max Daily Temp by City")
ax.legend()
plt.tight_layout()
plt.savefig("q3_multi_city_annual_avg.png")
plt.close()

# -------------------------------------------------------
# Q4: Seasonal histograms for 4 locations
# -------------------------------------------------------

city_dfs = [
    (df_aa, "Ann Arbor, MI"),
    (df_bh, "Blue Hill, MA"),
    (df_hou, "Houston, TX"),
    (df_la, "Los Angeles, CA"),
]
seasons = ["spring", "summer", "fall", "winter"]
season_colors = ["green", "orange", "brown", "steelblue"]

fig, axes = plt.subplots(2, 2, figsize=(12, 8))
axes = axes.flatten()

for i, (df, city_label) in enumerate(city_dfs):
    for season, color in zip(seasons, season_colors):
        subset = df[df["SEASON"] == season]["TMAX"].dropna()
        axes[i].hist(
            subset, bins=30, alpha=0.5, label=season, color=color
        )
    axes[i].set_title(city_label)
    axes[i].set_xlabel("Max Temperature")
    axes[i].set_ylabel("Count")
    axes[i].legend()

plt.suptitle("Seasonal Max Temperature Distributions")
plt.tight_layout()
plt.savefig("q4_seasonal_histograms.png")
plt.close()

# -------------------------------------------------------
# Q5: Average daily temps for 4 locations + normalized
# -------------------------------------------------------

fig, (ax1, ax2) = plt.subplots(2, 1, figsize=(12, 8))

for (df, label), color in zip(city_dfs, colors):
    avg = hwf.make_average_dataframe(df, column="DAY_OF_YEAR")
    tmax = avg["TMAX"].dropna()
    days = avg["DAY_OF_YEAR"][tmax.index]

    ax1.plot(days, tmax, color=color, label=label)

    tmax_norm = (tmax - tmax.min()) / (tmax.max() - tmax.min())
    ax2.plot(days, tmax_norm, color=color, label=label)

ax1.set_xlabel("Day of Year")
ax1.set_ylabel("Avg Max Temperature")
ax1.set_title("Average Max Temp by Day of Year")
ax1.legend()

ax2.set_xlabel("Day of Year")
ax2.set_ylabel("Normalized Temp (0 to 1)")
ax2.set_title("Normalized Average Max Temp by Day of Year")
ax2.legend()

plt.tight_layout()
plt.savefig("q5_avg_daily_temps.png")
plt.close()

# -------------------------------------------------------
# Q6: Houston - what part of year is most impacted?
# -------------------------------------------------------

df_hou_pre = df_hou[df_hou["YEAR"] < 1970]
df_hou_post = df_hou[df_hou["YEAR"] > 2000]

avg_pre = hwf.make_average_dataframe(df_hou_pre, column="DAY_OF_YEAR")
avg_post = hwf.make_average_dataframe(df_hou_post, column="DAY_OF_YEAR")

fig, ax = plt.subplots()
ax.plot(
    avg_pre["DAY_OF_YEAR"], avg_pre["TMAX"],
    color="steelblue", label="Before 1970"
)
ax.plot(
    avg_post["DAY_OF_YEAR"], avg_post["TMAX"],
    color="red", label="After 2000"
)
ax.set_xlabel("Day of Year")
ax.set_ylabel("Avg Max Temperature")
ax.set_title("Houston: Avg Max Temp by Day of Year (Early vs Recent)")
ax.legend()
plt.tight_layout()
plt.savefig("q6_houston_seasonal_change.png")
plt.close()
