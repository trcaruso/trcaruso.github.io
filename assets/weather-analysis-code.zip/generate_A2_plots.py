import historical_weather_functions as hwf
import matplotlib.pyplot as plt
import scipy.stats as stats

FNAME = 'ANN ARBOR U OF MICH, MI US.csv'

df = hwf.load_and_process_dataframe(FNAME)
hwf.label_days_and_year(df)
hwf.label_seasons(df)

# Plot 1: Max temperature on December 13 over all years
filtered = hwf.filter_by_month_and_day(df, month=12, day=13)
filtered = filtered.dropna(subset=["TMAX"])

slope, intercept, r, p, se = stats.linregress(
    filtered["YEAR"], filtered["TMAX"]
)
fit_line = slope * filtered["YEAR"] + intercept
p_label = f"fit: p={p:.1e}"

fig, ax = plt.subplots()
ax.scatter(
    filtered["YEAR"], filtered["TMAX"],
    label="TMAX on Dec 13", color="steelblue"
)
ax.plot(filtered["YEAR"], fit_line, color="red", label=p_label)
ax.set_xlabel("Year")
ax.set_ylabel("Max Temperature (tenths of C)")
ax.set_title("Max Daily Temp on December 13 Over Time (Ann Arbor)")
ax.legend()
plt.tight_layout()
plt.savefig("max_daily_temp_oneday.png")
plt.close()

# Plot 2: Annual average max temperature over all years
annual_avg = hwf.make_average_dataframe(df, column="YEAR")
annual_avg = annual_avg[1:-1]

slope2, intercept2, r2, p2, se2 = stats.linregress(
    annual_avg["YEAR"], annual_avg["TMAX"]
)
fit_line2 = slope2 * annual_avg["YEAR"] + intercept2
p2_label = f"fit: p={p2:.1e}"

fig, ax = plt.subplots()
ax.scatter(
    annual_avg["YEAR"], annual_avg["TMAX"],
    label="Annual Avg TMAX", color="steelblue"
)
ax.plot(annual_avg["YEAR"], fit_line2, color="red", label=p2_label)
ax.set_xlabel("Year")
ax.set_ylabel("Avg Max Temperature (tenths of C)")
ax.set_title("Annual Average Max Daily Temp Over Time (Ann Arbor)")
ax.legend()
plt.tight_layout()
plt.savefig("max_daily_temp_annual_average.png")
plt.close()

# Plot 3: Histograms of seasonal max temperatures
seasons = ["spring", "summer", "fall", "winter"]
colors = ["green", "orange", "brown", "steelblue"]

fig, ax = plt.subplots()
for season, color in zip(seasons, colors):
    subset = df[df["SEASON"] == season]["TMAX"].dropna()
    ax.hist(subset, bins=30, alpha=0.5, label=season, color=color)
ax.set_xlabel("Max Temperature (tenths of C)")
ax.set_ylabel("Count")
ax.set_title("Seasonal Max Temperature Distribution (Ann Arbor)")
ax.legend()
plt.tight_layout()
plt.savefig("seasons_histogram.png")
plt.close()

# Plot 4: Average max temp by day of year across three time periods
day_avg_all = hwf.make_average_dataframe(df, column="DAY_OF_YEAR")

df_pre1920 = df[df["YEAR"] < 1920]
day_avg_pre = hwf.make_average_dataframe(df_pre1920, column="DAY_OF_YEAR")

df_post2010 = df[df["YEAR"] > 2010]
day_avg_post = hwf.make_average_dataframe(df_post2010, column="DAY_OF_YEAR")

fig, ax = plt.subplots()
ax.plot(
    day_avg_all["DAY_OF_YEAR"], day_avg_all["TMAX"],
    color="black", label="All years"
)
ax.scatter(
    day_avg_pre["DAY_OF_YEAR"], day_avg_pre["TMAX"],
    color="steelblue", s=10, label="Before 1920"
)
ax.scatter(
    day_avg_post["DAY_OF_YEAR"], day_avg_post["TMAX"],
    color="red", s=10, label="After 2010"
)
ax.set_xlabel("Day of Year")
ax.set_ylabel("Avg Max Temperature (tenths of C)")
ax.set_title("Average Max Temp by Day of Year (Ann Arbor)")
ax.legend()
plt.tight_layout()
plt.savefig("avg_temps_over_days.png")
plt.close()
