import pandas as pd


def load_and_process_dataframe(filepath):
    # Load the CSV and convert DATE column to Pandas Timestamps
    df = pd.read_csv(filepath)
    df["DATE"] = pd.to_datetime(df["DATE"])
    return df


def label_days_and_year(df):
    # Add DAY_OF_YEAR and YEAR columns from the DATE Timestamp
    df["DAY_OF_YEAR"] = df["DATE"].dt.day_of_year
    df["YEAR"] = df["DATE"].dt.year


def filter_by_month_and_day(df, month, day):
    # Return rows where DATE matches the given month and day
    mask = (df["DATE"].dt.month == month) & (df["DATE"].dt.day == day)
    return df[mask]


def make_average_dataframe(df, column="YEAR"):
    # Average numeric columns grouped by the given column
    exclude = ["DATE"] + list(df.select_dtypes(include="object").columns)
    numeric_cols = [c for c in df.columns if c not in exclude]
    averaged = df[numeric_cols].groupby(column).mean()
    return averaged.reset_index()


def label_seasons(df):
    # Add a SEASON column based on the month of each DATE entry
    def get_season(month):
        if month in [3, 4, 5]:
            return "spring"
        elif month in [6, 7, 8]:
            return "summer"
        elif month in [9, 10, 11]:
            return "fall"
        else:
            return "winter"

    df["SEASON"] = df["DATE"].dt.month.apply(get_season)
